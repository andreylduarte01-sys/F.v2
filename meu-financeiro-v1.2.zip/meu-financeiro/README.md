# Meu Financeiro 1.0

Aplicativo web instalável (PWA) para finanças pessoais. Funciona offline após a primeira visita por HTTP(S) e usa `localStorage` no próprio dispositivo.

## Executar localmente

1. Extraia o ZIP.
2. Abra um terminal dentro da pasta `meu-financeiro`.
3. Execute `python -m http.server 8000` (ou `npx serve .`).
4. Acesse `http://localhost:8000`.

## Instalar no iPhone

Publique a pasta em um host HTTPS estático (por exemplo, GitHub Pages, Netlify ou Vercel). No Safari do iPhone, abra o endereço, toque em Compartilhar e escolha **Adicionar à Tela de Início**. O armazenamento é separado por navegador/dispositivo. Use Configurações > Exportar backup para preservar ou transferir dados.

## Recursos

- Dashboard, receitas fixas e extras, despesas, lançamentos recorrentes mensais
- Cartões (cadastro de limite e datas; **sem cálculo de fatura ou parcelamento**)
- Metas com progresso e contribuições manuais
- Orçamentos por categoria com avisos a partir de 85%
- Investimentos com valores manuais
- Relatórios mensais e gráficos de seis meses
- Backup JSON, importação e limpeza dos dados

## Limitações importantes

- Não há autenticação, integração bancária, sincronização entre dispositivos ou notificações push.
- Alertas só aparecem quando o aplicativo está aberto.
- O saldo é a diferença acumulada de lançamentos cadastrados, sem saldo inicial.
- Lançamentos recorrentes são projetados em meses posteriores, não são duplicados no banco de dados. Recorrências muito antigas são limitadas a 120 meses.
- Não é recomendável usar em dispositivos compartilhados. Exporte backups periodicamente.
- A carteira de investimentos não busca cotações e não representa recomendação financeira.


## Novidades v1.1
- Categoria Apostas e identificação assistida por palavras-chave na descrição.
- Alerta de risco de perda integral ao registrar depósitos em apostas.
- Totais registrados de apostas nos últimos 7 e 30 dias.
- Alertas de orçamento ao atingir 80% e 100% com um novo lançamento.
- Alertas exibidos dentro do aplicativo; **não são notificações push** e não monitoram transações bancárias automaticamente.
- Registre saques de apostas como receitas separadas; a análise de depósitos não representa resultado líquido.

## Versão 1.2 — Contas e dívidas
- Contas e dívidas com vencimentos, valores e categorias.
- Alertas internos de vencimento em até cinco dias e atraso.
- Planejamento mensal do salário e renda extra, deduzindo despesas lançadas e contas pendentes.
- Marcar como pago gera lançamento de despesa vinculado; desfazer remove esse lançamento.
- Parcelas devem ser cadastradas individualmente. Não há push em segundo plano, sincronização bancária ou parcelamento automático.
